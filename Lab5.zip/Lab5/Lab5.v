module Lab5 (
    input wire clk,
    input wire S1,
    input wire S2,
    output wire X,
    output wire Y,
    output reg buzzer = 1'b1
);

// ========================================
// COORDINATES AND DRAWING
// ========================================

reg [7:0] x = 128, y = 128;
reg [9:0] sx = 0, sy = 0;

reg [10:0] timer = 0;
reg phase = 0;          // 0 = WALID, 1 = LUANA
reg [5:0] segment = 0;
reg [6:0] t = 0;

// ========================================
// BUTTONS AND DEBOUNCING
// ========================================

reg s1a = 1, s1b = 1;
reg s2a = 1, s2b = 1;

reg [18:0] db1 = 0, db2 = 0;
reg k1 = 1, k2 = 1;
reg prev1 = 1, prev2 = 1;

wire press1 = prev1 && !k1;
wire press2 = prev2 && !k2;

// ========================================
// BUZZER
// ========================================

reg [13:0] tone_count = 0;
reg [21:0] beep_count = 0;

// ========================================
// LETTER DRAWING FUNCTION
// ========================================

function [31:0] shape;
    input p;
    input [5:0] s;

    reg [7:0] ox;
    reg [7:0] a, b, c, d;
    reg [2:0] letter;
    reg [2:0] line;

    begin
        letter = s / 8;
        line = s % 8;
        ox = 8'd12 + letter * 8'd47;

        a = 0;
        b = 128;
        c = 0;
        d = 128;

        case (p)

            // =================================
            // WALID
            // =================================
            0: begin
                case (letter)

                    // W
                    0: case (line)
                        0: begin a=0; b=190; c=8; d=65; end
                        1: begin a=8; b=65; c=17; d=130; end
                        2: begin a=17; b=130; c=26; d=65; end
                        3: begin a=26; b=65; c=34; d=190; end
                    endcase

                    // A
                    1: case (line)
                        0: begin a=0; b=65; c=17; d=190; end
                        1: begin a=17; b=190; c=34; d=65; end
                        2: begin a=8; b=125; c=26; d=125; end
                    endcase

                    // L
                    2: case (line)
                        0: begin a=0; b=190; c=0; d=65; end
                        1: begin a=0; b=65; c=34; d=65; end
                    endcase

                    // I
                    3: case (line)
                        0: begin a=0; b=190; c=34; d=190; end
                        1: begin a=17; b=190; c=17; d=65; end
                        2: begin a=0; b=65; c=34; d=65; end
                    endcase

                    // D
                    4: case (line)
                        0: begin a=0; b=65; c=0; d=190; end
                        1: begin a=0; b=190; c=24; d=190; end
                        2: begin a=24; b=190; c=34; d=170; end
                        3: begin a=34; b=170; c=34; d=85; end
                        4: begin a=34; b=85; c=24; d=65; end
                        5: begin a=24; b=65; c=0; d=65; end
                    endcase

                endcase
            end

            // =================================
            // LUANA
            // =================================
            1: begin
                case (letter)

                    // L
                    0: case (line)
                        0: begin a=0; b=190; c=0; d=65; end
                        1: begin a=0; b=65; c=34; d=65; end
                    endcase

                    // U
                    1: case (line)
                        0: begin a=0; b=190; c=0; d=85; end
                        1: begin a=0; b=85; c=10; d=65; end
                        2: begin a=10; b=65; c=24; d=65; end
                        3: begin a=24; b=65; c=34; d=85; end
                        4: begin a=34; b=85; c=34; d=190; end
                    endcase

                    // A
                    2: case (line)
                        0: begin a=0; b=65; c=17; d=190; end
                        1: begin a=17; b=190; c=34; d=65; end
                        2: begin a=8; b=125; c=26; d=125; end
                    endcase

                    // N
                    3: case (line)
                        0: begin a=0; b=65; c=0; d=190; end
                        1: begin a=0; b=190; c=34; d=65; end
                        2: begin a=34; b=65; c=34; d=190; end
                    endcase

                    // A
                    4: case (line)
                        0: begin a=0; b=65; c=17; d=190; end
                        1: begin a=17; b=190; c=34; d=65; end
                        2: begin a=8; b=125; c=26; d=125; end
                    endcase

                endcase
            end

        endcase

        shape = {ox+a, b, ox+c, d};
    end
endfunction

// ========================================
// SEGMENT ENDPOINTS
// ========================================

wire [31:0] v = shape(phase, segment);

wire [7:0] x0 = v[31:24];
wire [7:0] y0 = v[23:16];
wire [7:0] x1 = v[15:8];
wire [7:0] y1 = v[7:0];

wire signed [10:0] dx =
    $signed({1'b0, x1}) - $signed({1'b0, x0});

wire signed [10:0] dy =
    $signed({1'b0, y1}) - $signed({1'b0, y0});

wire signed [20:0] ix =
    $signed({1'b0, x0}) +
    (dx * $signed({1'b0, t})) / 63;

wire signed [20:0] iy =
    $signed({1'b0, y0}) +
    (dy * $signed({1'b0, t})) / 63;

// ========================================
// MAIN PROCESS
// ========================================

always @(posedge clk) begin

    // Synchronize buttons
    s1a <= S1;
    s1b <= s1a;
    s2a <= S2;
    s2b <= s2a;

    // Debounce S1
    if (s1b == k1)
        db1 <= 0;
    else if (db1 == 499999) begin
        db1 <= 0;
        k1 <= s1b;
    end
    else
        db1 <= db1 + 1'b1;

    // Debounce S2
    if (s2b == k2)
        db2 <= 0;
    else if (db2 == 499999) begin
        db2 <= 0;
        k2 <= s2b;
    end
    else
        db2 <= db2 + 1'b1;

    prev1 <= k1;
    prev2 <= k2;

    // Sigma-delta DAC
    sx <= {2'b00, sx[7:0]} + {2'b00, x};
    sy <= {2'b00, sy[7:0]} + {2'b00, y};

    // Change displayed name
    if (press1 || press2) begin
        phase <= ~phase;

        segment <= 0;
        t <= 0;
        timer <= 0;

        beep_count <= 4000000;
        tone_count <= 0;
        buzzer <= 1'b1;
    end
    else begin

        // Drawing engine
        if (timer == 346) begin
            timer <= 0;

            x <= ix[7:0];
            y <= iy[7:0];

            if (t == 63) begin
                t <= 0;

                if (segment == 39)
                    segment <= 0;
                else
                    segment <= segment + 1'b1;
            end
            else
                t <= t + 1'b1;
        end
        else
            timer <= timer + 1'b1;

        // Buzzer
        if (beep_count != 0) begin
            beep_count <= beep_count - 1'b1;

            if (tone_count == 12499) begin
                tone_count <= 0;
                buzzer <= ~buzzer;
            end
            else
                tone_count <= tone_count + 1'b1;
        end
        else begin
            buzzer <= 1'b1;
            tone_count <= 0;
        end
    end
end

// ========================================
// OUTPUTS
// ========================================

assign X = sx[8];
assign Y = sy[8];

endmodule