/* module RF_Generator (
    input wire clk,
    output reg rf_out = 0
);

reg [4:0] counter = 0;

always @(posedge clk) begin
    if (counter == 24) begin
        counter <= 0;
        rf_out <= ~rf_out;
    end
    else begin
        counter <= counter + 1;
    end
end

endmodule
*/

/*
module RF_Generator (
    input wire clk,                  // 50 MHz
    output wire rf_out
);
    reg [4:0] rf_count = 0;
    reg carrier = 0;
    reg [14:0] audio_count = 0;
    reg audio = 0;

    always @(posedge clk) begin
        if (rf_count == 24) begin
            rf_count <= 0;
            carrier <= ~carrier;
        end else rf_count <= rf_count + 1;
    end

    always @(posedge clk) begin      // Ton de 1 kHz
        if (audio_count == 24999) begin
            audio_count <= 0;
            audio <= ~audio;
        end else audio_count <= audio_count + 1;
    end

    assign rf_out = carrier & audio; // Modulatie ON/OFF (OOK)
endmodule
*/

module RF_Generator (
    input wire clk,
    output wire rf_out
);

// ========================================
// 1. RF CARRIER - 1 MHz
// ========================================

reg [4:0] rf_count = 0;
reg carrier = 0;

always @(posedge clk) begin
    if (rf_count == 24) begin
        rf_count <= 0;
        carrier <= ~carrier;
    end
    else begin
        rf_count <= rf_count + 1;
    end
end

// ========================================
// 2. MUSIC NOTES
// ========================================

// Note frequencies:
// E5 = 659 Hz
// B4 = 494 Hz
// C5 = 523 Hz
// D5 = 587 Hz
// A4 = 440 Hz
// G4 = 392 Hz

reg [15:0] note_divider = 37936;
reg [15:0] note_counter = 0;
reg audio = 0;

reg [4:0] note_index = 0;

// ========================================
// 3. NOTE DURATION
// ========================================

// Each note lasts 250 ms

reg [23:0] duration_counter = 0;

always @(posedge clk) begin
    if (duration_counter == 12499999) begin
        duration_counter <= 0;

        if (note_index == 15)
            note_index <= 0;
        else
            note_index <= note_index + 1;
    end
    else begin
        duration_counter <= duration_counter + 1;
    end
end

// ========================================
// 4. TETRIS MELODY
// ========================================

always @(*) begin
    case (note_index)

        0:  note_divider = 37936; // E5
        1:  note_divider = 37936; // E5
        2:  note_divider = 50607; // B4
        3:  note_divider = 47778; // C5

        4:  note_divider = 42589; // D5
        5:  note_divider = 47778; // C5
        6:  note_divider = 50607; // B4
        7:  note_divider = 56818; // A4

        8:  note_divider = 56818; // A4
        9:  note_divider = 47778; // C5
        10: note_divider = 37936; // E5
        11: note_divider = 42589; // D5

        12: note_divider = 47778; // C5
        13: note_divider = 50607; // B4
        14: note_divider = 50607; // B4
        15: note_divider = 56818; // A4

        default: note_divider = 37936;

    endcase
end

// ========================================
// 5. GENERATE AUDIO
// ========================================

always @(posedge clk) begin
    if (note_counter >= note_divider - 1) begin
        note_counter <= 0;
        audio <= ~audio;
    end
    else begin
        note_counter <= note_counter + 1;
    end
end

// ========================================
// 6. OOK MODULATION
// ========================================

assign rf_out = carrier & audio;

endmodule